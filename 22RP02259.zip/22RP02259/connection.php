<?php
try{
$conn=mysqli_connect("localhost","root","","php_work");
}
catch(SQLException $e){
    echo $e->getMessage;

}
?>