<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f0f0;
            margin: 0;
        }
        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        input[type="checkbox"] {
            margin-right: 5px;
        }
        button {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
        .error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <form action="" method="POST">
        <label for="username">User Name</label>
        <input type="text" name="username" id="username"><br>
        <label for="password">Password</label>
        <input type="password" name="password" id="password"><br>
        <input type="checkbox" name="remember" value="1">Remember me<br>
        <button type="submit">Login</button>
    </form>
</body>
</html>

<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    include 'connection.php';
    $name = trim($_POST['username']);
    $pass = trim($_POST['password']);
    $remember = isset($_POST['remember']);

    if (!empty($name) && !empty($pass)) {
        $name = mysqli_real_escape_string($conn, $name);
        $pass = mysqli_real_escape_string($conn, $pass);
        $query = mysqli_query($conn, "SELECT * FROM users WHERE username='$name' AND password='$pass'");
        $num = mysqli_num_rows($query);
        if ($num) {
            $_SESSION['user'] = $name;
            if ($remember) {
                // Set cookie for 30 days
                setcookie('username', $name, time() + (86400 * 30), "/");
                setcookie('password', $pass, time() + (86400 * 30), "/");
            } else {
                // Clear cookies if 'Remember Me' is not checked
                setcookie('username', '', time() - 3600, "/");
                setcookie('password', '', time() - 3600, "/");
            }
            echo "<script>alert('Welcome $name'); location='dashboard.php';</script>";
        } else {
            echo "<script>alert('Access denied');</script>";
        }
    } else {
        echo "<script>alert('Both fields must be filled');</script>";
    }
}
?>
