<?php
include 'dashboard.php';
?>
<br><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Student</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
   
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 600px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="number"]{
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
       
        button {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #218838;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="POST">
            <label for="fname">First Name</label>
            <input type="text" id="fname" name="fname" required>
            
            <label for="lname">Last Name</label>
            <input type="text" id="lname" name="lname" required>
            
            <label for="age">Student Age</label>
            <input type="number" id="age" name="age" required>
            
            <label for="gender">Gender</label>
            <input type="radio" id="male" name="gender" value="male" required>
            <label for="male">Male</label>
            <input type="radio" id="female" name="gender" value="female" required>
            <label for="female">Female</label>
            
            <label for="department">Department</label>
            <input type="text" id="department" name="department" required>
            
            <label for="year">Year of Study</label>
            <input type="text" id="year" name="year" required>
            
            <button type="submit" name="submit">Add Student</button>
        </form>
    </div>

    <?php
    if (isset($_POST['submit'])) {
        include 'connection.php';
        $fname = mysqli_real_escape_string($conn, $_POST['fname']);
        $lname = mysqli_real_escape_string($conn, $_POST['lname']);
        $age = mysqli_real_escape_string($conn, $_POST['age']);
        $gender = mysqli_real_escape_string($conn, $_POST['gender']);
        $dept = mysqli_real_escape_string($conn, $_POST['department']);
        $year = mysqli_real_escape_string($conn, $_POST['year']);

        $query = "INSERT INTO studentInfo (fname, lname, age, gender, department, year) VALUES ('$fname', '$lname', '$age', '$gender', '$dept', '$year')";
        $result = mysqli_query($conn, $query);

        if ($result) {
            echo"<script>alert('Student added successfully!'),location='viewstudent.php'</script>";
            
        } else {
            echo"<script>alert('Error adding student.')</script>";
            
        }
    }
    ?>
</body>
</html>
