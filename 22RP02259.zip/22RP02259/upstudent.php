<?php
include 'dashboard.php';
include 'connection.php';
$stid=$_GET['stid'];
$query=mysqli_query($conn,"SELECT * FROM studentInfo where stid='$stid'");
$row=mysqli_fetch_array($query);
?>
<br><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
   
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            width: 80%;
            max-width: 600px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"], input[type="number"]{
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
       
        button {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #218838;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<center>
    <form action="" method="POST">
        <label for="">First Name</label><br>
        <input type="text" name="fname" value="<?php echo $row['fname']?>"><br>
        <label for="">Last Name</label><br>
        <input type="text" name="lname" value="<?php echo $row['lname']?>"><br>
        <label for="">Student Age</label><br>
        <input type="number" name="age" value="<?php echo $row['age']?>"><br>
        <label for="">Gender</label><br>
        <input type="text" name="gender" value="<?php echo $row['gender']?>"><br>
        
        <label for="">Department</label><br>
        <input type="text" name="department" value="<?php echo $row['department']?>"><br>
        <label for="">Year of study</label><br>
        <input type="text" name="year" value="<?php echo $row['year']?>"><br><br>
        <button type="submit" name="submit">Update Student</button>
        </center>


    </form>
</body>
</html>
<?php
if(isset($_POST['submit'])){
    $stid=$_GET['stid'];
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $age=$_POST['age'];
    $gender=$_POST['gender'];
    $dept=$_POST['department'];
    $year=$_POST['year'];
   
    $query=mysqli_query($conn,"UPDATE studentInfo set fname='$fname',lname='$lname',age='$age',gender='$gender',department='$dept',year='$year' where stid='$stid'");
    if($query==1){
        echo"<script>alert('Successfull updated'),location='viewstudent.php'</script>";
    }
    else{
        echo"<script>alert('Not Updated'),location='viewstudent.php'</script>";
    }

}
?>