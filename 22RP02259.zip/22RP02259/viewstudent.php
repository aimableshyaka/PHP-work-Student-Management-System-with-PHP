<?php
include 'dashboard.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information</title>
    <style>

        .container {
            width: 90%;
            max-width: 1200px;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            background-color: white;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #eaeaea;
        }
        a {
            color: #3498db;
            text-decoration: none;
            font-weight: bold;
        }
        a:hover {
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            table, th, td {
                display: block;
                width: 100%;
            }
            th, td {
                padding: 10px;
                box-sizing: border-box;
            }
            thead {
                display: none;
            }
            tr {
                margin-bottom: 15px;
                display: block;
                background: #fff;
                border-radius: 5px;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }
            td {
                display: block;
                text-align: right;
                position: relative;
                padding-left: 50%;
            }
            td::before {
                content: attr(data-label);
                position: absolute;
                left: 0;
                width: 50%;
                padding-left: 10px;
                font-weight: bold;
                white-space: nowrap;
                background-color: #f2f2f2;
                border-bottom: 1px solid #ddd;
            }
        }
    </style>
</head>
<body>
    <br><br><br>
    <div class="container">
        <table>
            <thead>
                <tr>
                    <th>User Id</th>
                    <th>FIRST NAME</th>
                    <th>LAST NAME</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Department</th>
                    <th>Year Of Study</th>
                    <th colspan="2">Option</th>
                </tr>
            </thead>
            <tbody>
                <?php
                require 'connection.php';
                $query = mysqli_query($conn, "SELECT * FROM studentInfo");
                while ($row = mysqli_fetch_array($query)) {
                    ?>
                    <tr>
                        <td><?php echo $row['stid'] ?></td>
                        <td><?php echo $row['fname'] ?></td>
                        <td><?php echo $row['lname'] ?></td>
                        <td><?php echo $row['age'] ?></td>
                        <td><?php echo $row['gender'] ?></td>
                        <td><?php echo $row['department'] ?></td>
                        <td><?php echo $row['year'] ?></td>
                        <td><a href="deletestudent.php?stid=<?php echo $row['stid'] ?>">Delete</a></td>
                        <td><a href="upstudent.php?stid=<?php echo $row['stid'] ?>">Update</a></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
