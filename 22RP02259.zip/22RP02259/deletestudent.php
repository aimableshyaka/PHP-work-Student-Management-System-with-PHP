<?php
require 'connection.php';
$stid=$_GET['stid'];
$query=mysqli_query($conn,"DELETE from studentInfo where stid='$stid'");
header("location:viewstudent.php");
?>